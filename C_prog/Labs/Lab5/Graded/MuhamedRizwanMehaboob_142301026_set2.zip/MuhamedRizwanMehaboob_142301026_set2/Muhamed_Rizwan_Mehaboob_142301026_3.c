#include <stdio.h>
#include <stdlib.h>

/*
In this problem, we are given as input the number of elements odf the array,
the array elements and the left and right index. We have to reverse the 
array in the slice between this L and R indexes. For that we just need to
iterae through the array until the midpoint between R and L. And as we iterate
we swap the ith from the left side and ith elemetn from the right side until we
get the final array.
*/

int reversesubarray(int* arr, int n, int l, int r) {
    for (int i=0; i<((r-l)/2)+1; i++) {
        int temp = *(arr+i+l-1);
        *(arr+i+l-1) = *(arr+r-i-1);
        *(arr+r-i-1) = temp;
    }
    for (int i=0; i<n; i++) printf("%d ", *(arr+i));
    return 0;
}


int main() {
    int n, l, r;
    scanf("%d", &n);
    int* arr = (int *)malloc(n*sizeof(int));
    
    if (arr == NULL) {
        printf("Memory Allocation Failed!!!");
        return 1;
    }

    for (int i=0; i<n; i++) {
        scanf("%d",arr+i);
    }

    scanf("%d %d", &l, &r);

    reversesubarray(arr, n, l, r);
    free(arr);
    return 0;
}